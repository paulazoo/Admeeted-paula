synapse.util.dbutils module
===========================

.. automodule:: synapse.util.dbutils
    :members:
    :undoc-members:
    :show-inheritance:
