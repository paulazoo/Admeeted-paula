sphinx-apidoc -o docs/sphinx/ synapse/ -ef
