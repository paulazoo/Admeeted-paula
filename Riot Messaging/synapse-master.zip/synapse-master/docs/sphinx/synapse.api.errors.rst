synapse.api.errors module
=========================

.. automodule:: synapse.api.errors
    :members:
    :undoc-members:
    :show-inheritance:
