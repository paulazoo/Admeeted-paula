synapse.api.dbobjects module
============================

.. automodule:: synapse.api.dbobjects
    :members:
    :undoc-members:
    :show-inheritance:
