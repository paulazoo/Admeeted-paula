synapse.api.handlers package
============================

Submodules
----------

.. toctree::

   synapse.api.handlers.events
   synapse.api.handlers.factory
   synapse.api.handlers.federation
   synapse.api.handlers.register
   synapse.api.handlers.room

Module contents
---------------

.. automodule:: synapse.api.handlers
    :members:
    :undoc-members:
    :show-inheritance:
