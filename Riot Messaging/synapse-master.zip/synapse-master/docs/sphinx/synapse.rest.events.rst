synapse.rest.events module
==========================

.. automodule:: synapse.rest.events
    :members:
    :undoc-members:
    :show-inheritance:
