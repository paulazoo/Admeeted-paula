print(str(len("deshonmohsinboi@gmail.com")))
print(str(len("deshonmohsinboigmail.com")))