synapse.persistence.tables module
=================================

.. automodule:: synapse.persistence.tables
    :members:
    :undoc-members:
    :show-inheritance:
