synapse.api.storage module
==========================

.. automodule:: synapse.api.storage
    :members:
    :undoc-members:
    :show-inheritance:
