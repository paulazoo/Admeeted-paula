synapse package
===============

Subpackages
-----------

.. toctree::

    synapse.api
    synapse.app
    synapse.federation
    synapse.persistence
    synapse.rest
    synapse.util

Submodules
----------

.. toctree::

   synapse.server
   synapse.state

Module contents
---------------

.. automodule:: synapse
    :members:
    :undoc-members:
    :show-inheritance:
