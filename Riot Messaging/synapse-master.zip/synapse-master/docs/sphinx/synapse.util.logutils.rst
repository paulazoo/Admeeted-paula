synapse.util.logutils module
============================

.. automodule:: synapse.util.logutils
    :members:
    :undoc-members:
    :show-inheritance:
