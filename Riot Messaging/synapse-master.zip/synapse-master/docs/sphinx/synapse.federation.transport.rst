synapse.federation.transport module
===================================

.. automodule:: synapse.federation.transport
    :members:
    :undoc-members:
    :show-inheritance:
