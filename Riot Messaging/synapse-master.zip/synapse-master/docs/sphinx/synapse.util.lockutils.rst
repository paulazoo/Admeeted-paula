synapse.util.lockutils module
=============================

.. automodule:: synapse.util.lockutils
    :members:
    :undoc-members:
    :show-inheritance:
