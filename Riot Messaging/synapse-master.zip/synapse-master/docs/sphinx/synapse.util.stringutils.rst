synapse.util.stringutils module
===============================

.. automodule:: synapse.util.stringutils
    :members:
    :undoc-members:
    :show-inheritance:
