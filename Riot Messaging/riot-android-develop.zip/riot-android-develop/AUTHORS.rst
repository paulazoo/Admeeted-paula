Joachim reigle <Joachim at matrix.org>
 * First implementations of the Android client.

Kegan Dougal <kegan at matrix.org>
  * Developer.

Yannick Le Collen <yannick at matrix.org>
  * Developer.

Pedro Contreiras <pedro at matrix.org>
  * Developer. 
  
Sabrina Jeanne <sabrina at matrix.org>
   * Developer.

Leon Handreke <leonh at matrix.org>
  * First implementation of GCM (Google Cloud Messaging).

Friedger Müffke <friedger at matrix.org>
  * Google car implementation.

Matthew Hodgson <matthew at matrix.org>
 * General documentation improvements and housekeeping.

Florent Violleau <floviolleau at gmail dot com>
 * General documentation improvements.

Jay Kamat <jaygkamat at gmail dot com>
 * Contribution on the dark theme.
 
Pierre Jaury <pierre at jaury.eu>
 * PR #1784: Code: Tidy codebase
 
Nolan Darilek <nolan at thewordnerd.info>
 * PR #1976: Label bunches of actionable room items for screen readers.

Chris Tarazi <tarazichris at gmail.com>
 * PR #2019: File uploads with file name containing a path to fix matrix-org/matrix-android-sdk#228.
 
Safa AlFulaij <safa1996alfulaij at gmail.com>
 * PR #1934: Fix some plural messages.

Isa Cichon <isa4 at posteo.net>
 *  Add spacing to device keys

Nathan van Beelen <nathan at vanbeelen.org>
 * PR #1742: Add a media previewer

Blue <blue at bluecode.fr>
 * Propagate error messages from 3PID and display them during signup

Ville Ranki <ville.ranki at iki.fi>
 * Fix avatar icon characters being offset

Viktor Liu <vma+github at randomcrap.eu>
 * Add option to send messages with enter button
