synapse.persistence.service module
==================================

.. automodule:: synapse.persistence.service
    :members:
    :undoc-members:
    :show-inheritance:
