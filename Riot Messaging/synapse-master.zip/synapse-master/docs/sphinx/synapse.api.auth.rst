synapse.api.auth module
=======================

.. automodule:: synapse.api.auth
    :members:
    :undoc-members:
    :show-inheritance:
