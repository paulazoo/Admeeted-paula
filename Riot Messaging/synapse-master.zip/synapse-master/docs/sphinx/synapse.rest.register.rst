synapse.rest.register module
============================

.. automodule:: synapse.rest.register
    :members:
    :undoc-members:
    :show-inheritance:
