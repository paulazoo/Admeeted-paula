synapse.api.events.room module
==============================

.. automodule:: synapse.api.events.room
    :members:
    :undoc-members:
    :show-inheritance:
