synapse.federation.handler module
=================================

.. automodule:: synapse.federation.handler
    :members:
    :undoc-members:
    :show-inheritance:
