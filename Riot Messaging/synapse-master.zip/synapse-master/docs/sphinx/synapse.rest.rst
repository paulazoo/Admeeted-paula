synapse.rest package
====================

Submodules
----------

.. toctree::

   synapse.rest.base
   synapse.rest.events
   synapse.rest.register
   synapse.rest.room

Module contents
---------------

.. automodule:: synapse.rest
    :members:
    :undoc-members:
    :show-inheritance:
