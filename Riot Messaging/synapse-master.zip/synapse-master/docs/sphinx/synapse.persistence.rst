synapse.persistence package
===========================

Submodules
----------

.. toctree::

   synapse.persistence.service
   synapse.persistence.tables
   synapse.persistence.transactions

Module contents
---------------

.. automodule:: synapse.persistence
    :members:
    :undoc-members:
    :show-inheritance:
