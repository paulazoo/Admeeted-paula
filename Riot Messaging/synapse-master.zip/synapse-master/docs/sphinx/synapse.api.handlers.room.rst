synapse.api.handlers.room module
================================

.. automodule:: synapse.api.handlers.room
    :members:
    :undoc-members:
    :show-inheritance:
