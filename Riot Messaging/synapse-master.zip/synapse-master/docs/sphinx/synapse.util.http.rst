synapse.util.http module
========================

.. automodule:: synapse.util.http
    :members:
    :undoc-members:
    :show-inheritance:
