synapse.api.server module
=========================

.. automodule:: synapse.api.server
    :members:
    :undoc-members:
    :show-inheritance:
