---
name: Support request
about: I need support for Synapse

---

Please don't file github issues asking for support.

Instead, please join [`#synapse:matrix.org`](https://matrix.to/#/#synapse:matrix.org)
(from a matrix.org account if necessary), and ask there.
