synapse.persistence.transactions module
=======================================

.. automodule:: synapse.persistence.transactions
    :members:
    :undoc-members:
    :show-inheritance:
