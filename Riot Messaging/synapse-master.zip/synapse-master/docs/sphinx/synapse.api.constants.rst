synapse.api.constants module
============================

.. automodule:: synapse.api.constants
    :members:
    :undoc-members:
    :show-inheritance:
