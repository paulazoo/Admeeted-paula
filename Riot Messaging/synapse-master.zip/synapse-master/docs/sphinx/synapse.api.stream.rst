synapse.api.stream module
=========================

.. automodule:: synapse.api.stream
    :members:
    :undoc-members:
    :show-inheritance:
