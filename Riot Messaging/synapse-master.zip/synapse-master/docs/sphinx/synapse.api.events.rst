synapse.api.events package
==========================

Submodules
----------

.. toctree::

   synapse.api.events.factory
   synapse.api.events.room

Module contents
---------------

.. automodule:: synapse.api.events
    :members:
    :undoc-members:
    :show-inheritance:
