synapse.api.notifier module
===========================

.. automodule:: synapse.api.notifier
    :members:
    :undoc-members:
    :show-inheritance:
