synapse.rest.base module
========================

.. automodule:: synapse.rest.base
    :members:
    :undoc-members:
    :show-inheritance:
