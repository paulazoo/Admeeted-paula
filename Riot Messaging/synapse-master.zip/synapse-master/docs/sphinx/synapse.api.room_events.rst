synapse.api.room_events module
==============================

.. automodule:: synapse.api.room_events
    :members:
    :undoc-members:
    :show-inheritance:
