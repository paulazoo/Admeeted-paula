synapse.api.handlers.federation module
======================================

.. automodule:: synapse.api.handlers.federation
    :members:
    :undoc-members:
    :show-inheritance:
