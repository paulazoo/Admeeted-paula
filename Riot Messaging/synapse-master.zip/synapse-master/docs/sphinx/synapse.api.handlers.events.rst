synapse.api.handlers.events module
==================================

.. automodule:: synapse.api.handlers.events
    :members:
    :undoc-members:
    :show-inheritance:
