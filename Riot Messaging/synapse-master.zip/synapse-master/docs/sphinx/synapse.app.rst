synapse.app package
===================

Submodules
----------

.. toctree::

   synapse.app.homeserver

Module contents
---------------

.. automodule:: synapse.app
    :members:
    :undoc-members:
    :show-inheritance:
