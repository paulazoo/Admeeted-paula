synapse.state module
====================

.. automodule:: synapse.state
    :members:
    :undoc-members:
    :show-inheritance:
