synapse.api.streams.event module
================================

.. automodule:: synapse.api.streams.event
    :members:
    :undoc-members:
    :show-inheritance:
