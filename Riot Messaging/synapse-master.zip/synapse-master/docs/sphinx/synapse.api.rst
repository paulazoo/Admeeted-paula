synapse.api package
===================

Subpackages
-----------

.. toctree::

    synapse.api.events
    synapse.api.handlers
    synapse.api.streams

Submodules
----------

.. toctree::

   synapse.api.auth
   synapse.api.constants
   synapse.api.errors
   synapse.api.notifier
   synapse.api.storage

Module contents
---------------

.. automodule:: synapse.api
    :members:
    :undoc-members:
    :show-inheritance:
