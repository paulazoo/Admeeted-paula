synapse.api.handlers.register module
====================================

.. automodule:: synapse.api.handlers.register
    :members:
    :undoc-members:
    :show-inheritance:
