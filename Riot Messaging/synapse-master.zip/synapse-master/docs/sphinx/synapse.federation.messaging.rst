synapse.federation.messaging module
===================================

.. automodule:: synapse.federation.messaging
    :members:
    :undoc-members:
    :show-inheritance:
