synapse.federation.units module
===============================

.. automodule:: synapse.federation.units
    :members:
    :undoc-members:
    :show-inheritance:
