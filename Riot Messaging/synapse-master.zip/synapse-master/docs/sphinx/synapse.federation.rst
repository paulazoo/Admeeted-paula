synapse.federation package
==========================

Submodules
----------

.. toctree::

   synapse.federation.handler
   synapse.federation.pdu_codec
   synapse.federation.persistence
   synapse.federation.replication
   synapse.federation.transport
   synapse.federation.units

Module contents
---------------

.. automodule:: synapse.federation
    :members:
    :undoc-members:
    :show-inheritance:
