.. Synapse documentation master file, created by
   sphinx-quickstart on Tue Jun 10 17:31:02 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Synapse's documentation!
===================================

Contents:

.. toctree::
   synapse

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

