package im.vector.listeners;

public interface ItemPositionChangedListener {
    void onItemPositionChangedListener(int position);
}
