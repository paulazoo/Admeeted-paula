synapse.api.handlers.factory module
===================================

.. automodule:: synapse.api.handlers.factory
    :members:
    :undoc-members:
    :show-inheritance:
