Protocol Documentation
======================

The Hangouts protocol is undocumented, as such any documentation here is
unofficial and liable to be incomplete and/or incorrect.

.. toctree::
   :maxdepth: 1

   protobuf
