synapse.api.events.factory module
=================================

.. automodule:: synapse.api.events.factory
    :members:
    :undoc-members:
    :show-inheritance:
