synapse.api.register_events module
==================================

.. automodule:: synapse.api.register_events
    :members:
    :undoc-members:
    :show-inheritance:
