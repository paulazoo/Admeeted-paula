synapse.rest.room module
========================

.. automodule:: synapse.rest.room
    :members:
    :undoc-members:
    :show-inheritance:
