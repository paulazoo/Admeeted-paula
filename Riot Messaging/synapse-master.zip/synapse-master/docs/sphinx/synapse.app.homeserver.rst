synapse.app.homeserver module
=============================

.. automodule:: synapse.app.homeserver
    :members:
    :undoc-members:
    :show-inheritance:
