synapse.api.event_stream module
===============================

.. automodule:: synapse.api.event_stream
    :members:
    :undoc-members:
    :show-inheritance:
