synapse.federation.pdu_codec module
===================================

.. automodule:: synapse.federation.pdu_codec
    :members:
    :undoc-members:
    :show-inheritance:
