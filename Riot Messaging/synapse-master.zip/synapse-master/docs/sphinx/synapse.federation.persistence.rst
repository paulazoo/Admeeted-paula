synapse.federation.persistence module
=====================================

.. automodule:: synapse.federation.persistence
    :members:
    :undoc-members:
    :show-inheritance:
